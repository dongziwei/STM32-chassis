#ifndef __TB_RCC_H__
#define __TB_RCC_H__


void rcc_init(void);


#endif


