#ifndef __DELAY_H__
#define __DELAY_H__

#include "z_type.h"

#define mdelay(x) delay_ms(x)

void delay_init(void);
void delay(u16 t);
void delay_ns(u16 t);
void delay_us(u16 t);
void delay_ms(u16 t);




#endif

